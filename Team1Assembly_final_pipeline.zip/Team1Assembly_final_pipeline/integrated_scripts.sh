#!/bin/bash

##Script for Trimming
mkdir temp_trimming
mypwd=`pwd`
input_fold=$mypwd/fastqRaw # fastqRaw is a folder created before storing raw fastq files
out_fold=$mypwd/temp_trimming
trimmomatic_path=/projects/data/team1_genomeAssembly/local/bin
adapters_path=$mypwd
echo "Run trimmomatic for all files"
mkdir $out_fold/fastq


for f in $(cat $mypwd/ID.txt)
do
    java -jar ${trimmomatic_path}/trimmomatic-0.36.jar PE \
    ${input_fold}/${f}_1.fastq \
    ${input_fold}/${f}_2.fastq \
    ${out_fold}/fastq/${f}_forward_paired.fq \
    ${out_fold}/fastq/${f}_forward_unpaired.fq \
    ${out_fold}/fastq/${f}_reverse_paired.fq \
    ${out_fold}/fastq/${f}_reverse_unpaired.fq \
    ILLUMINACLIP:${adapters_path}/adapters.fa:5:30:10 \
    SLIDINGWINDOW:4:20 MINLEN:20
done

echo "Running FastQC"

mkdir $out_fold/fastq/fastqc

for f in $(ls ${out_fold}/fastq)
do
    echo $f
    fastqc ${out_fold}/fastq/${f} \
    -o ${out_fold}/fastq/fastqc
done

##End of script for trimming

