import os
import shutil
import subprocess

pwd = subprocess.check_output("pwd")
pwd = pwd.strip('\n')
fileDir = pwd + "/temp_trimming/fastq"
libFile = pwd + "/denovo_skesa/sspaceLibrary"


# preparing a list of all the IDs
def generateGeneList():
        geneList = []
        for file in os.listdir(fileDir):
                if file.endswith(".fq"):
                        a,b,c = file.split('_')
                        geneList.append(a)


        unique_geneList = (list(set(geneList)))
        return unique_geneList


# Running skesa (denovo assembly) command on all the forward and reverse paired files
def runSkesa(geneList):
        for a in geneList:
                fFile = "/%s_forward_paired.fq" %(a)
                rFile = "/%s_reverse_paired.fq" %(a)
                forwardFile = fileDir + fFile
                reverseFile = fileDir + rFile
                #print (forwardFile,reverseFile)
		os.mkdir("%s/denovo_skesa/skesaoutput" %(pwd))
                skesaCmd = 'skesa --fastq %s --fastq %s --contigs_out %s/denovo_skesa/skesaoutput/%s.skesa.fa' %(forwardFile,reverseFile,pwd,a)
                os.system(skesaCmd)

# Building a library with forward and reverse paired files, insert size for paired reads, error rate, ForwardReverse order, to run SSPACE

def generateLibFiles(geneList):
        for gene in geneList:

                libFileName  = '%s/%s'%(libFile,gene)

                libText="%s_lib %s/%s_forward_paired.fq %s/%s_reverse_paired.fq 500 0.75 FR" %(gene,fileDir,gene,fileDir,gene)
                if not os.path.exists(libFileName):
                        with open(libFileName,'w') as fh:
                                fh.write(libText)
                                fh.close()
# Running the SSPACE command for scaffolding using default parameters and contig extension (-x 1)

                sspaceCmd = "perl %s/SSPACE/sspace_basic/SSPACE_Basic.pl -l %s/%s -s %s/denovo_skesa/skesaoutput/%s.skesa.fa -x 1 -T 8 -b %s.sspace -m 20 -o 15 -a 0.8 -n 12 -g 3 -p 1" %(pwd,libFile,gene,pwd,gene,gene)


                os.system(sspaceCmd)
                print("Done scaffolding")

# Remove all the folders created during scaffolding to minimize use of space
                shutil.rmtree(pwd + "/reads")
                shutil.rmtree(pwd + "/bowtieoutput")
                shutil.rmtree(pwd + "/pairinfo")
                shutil.rmtree(pwd + "/intermediate_results")
                shutil.rmtree(pwd + "/dotfiles")


geneList = generateGeneList()
runSkesa(geneList)
generateLibFiles(geneList)

